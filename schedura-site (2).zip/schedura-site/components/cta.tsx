"use client"

import { useEffect, useRef } from "react"
import { gsap } from "gsap"
import { ScrollTrigger } from "gsap/ScrollTrigger"

gsap.registerPlugin(ScrollTrigger)

export default function CTA() {
  const sectionRef = useRef<HTMLElement>(null)
  const headingRef = useRef<HTMLHeadingElement>(null)
  const paragraphRef = useRef<HTMLParagraphElement>(null)
  const buttonRef = useRef<HTMLButtonElement>(null)

  useEffect(() => {
    const tl = gsap.timeline({
      scrollTrigger: {
        trigger: sectionRef.current,
        start: "top 80%",
        toggleActions: "play none none none"
      }
    })

    tl.from(headingRef.current, {
      opacity: 0,
      y: 40,
      duration: 1,
      ease: "power3.out"
    })
    .from(paragraphRef.current, {
      opacity: 0,
      y: 30,
      duration: 0.8,
      ease: "power3.out"
    }, "-=0.5")
    .from(buttonRef.current, {
      opacity: 0,
      scale: 0.9,
      duration: 0.6,
      ease: "back.out(1.7)"
    }, "-=0.4")

    // Button pulse animation
    gsap.to(buttonRef.current, {
      scale: 1.05,
      duration: 0.8,
      repeat: -1,
      yoyo: true,
      ease: "sine.inOut"
    })
  }, [])

  return (
    <section 
      ref={sectionRef} 
      className="py-20 md:py-32 bg-white"
    >
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h2 
          ref={headingRef} 
          className="text-3xl md:text-5xl font-bold text-black mb-4"
        >
          Ready to Modernize Your Space Management?
        </h2>
        <p 
          ref={paragraphRef} 
          className="text-lg text-black/70 mb-12"
        >
          Discover how Schedura can eliminate booking conflicts and provide actionable analytics for smarter, sustainable, and user-centric space utilization.
        </p>

        <div className="flex flex-col sm:flex-row gap-6 justify-center items-center">
          <button 
            ref={buttonRef}
            className="bg-black text-white px-8 py-3 rounded-full font-semibold hover:bg-gray-800 transition-all duration-300"
          >
            Schedule a Free Demo
          </button>
        </div>
      </div>
    </section>
  )
}