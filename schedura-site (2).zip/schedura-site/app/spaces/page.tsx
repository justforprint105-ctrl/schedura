"use client"

import { useEffect, useRef, useState } from "react"
import Link from "next/link"
import { gsap } from "gsap"
import { ScrollTrigger } from "gsap/ScrollTrigger"
import { MapPin, Users, DollarSign, ArrowRight, Filter, Search } from "lucide-react"
import { supabase } from "@/lib/supabase"

gsap.registerPlugin(ScrollTrigger)

interface Space {
  id: string
  name: string
  location: string
  capacity: number
  pph: number
  category: string
  description: string
}

interface SpaceWithImage extends Space {
  image: string
}

const SpaceCard = ({ space, index }: { space: SpaceWithImage; index: number }) => {
  const cardRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const ctx = gsap.context(() => {
      if (cardRef.current) {
        gsap.from(cardRef.current, {
          opacity: 0,
          y: 60,
          duration: 0.8,
          delay: index * 0.01,
          ease: "power3.out",
          scrollTrigger: {
            trigger: cardRef.current,
            start: "top 90%",
            toggleActions: "play none none none",
          },
        })
      }
    }, cardRef)

    return () => {
      ctx.revert()
    }
  }, [index])

  return (
    <Link href={`/spaces/${space.id}`}>
      <div
        ref={cardRef}
        className="group relative bg-white rounded-2xl overflow-hidden border border-black/10 hover:shadow-xl transition-all duration-500 cursor-pointer"
      >
        {/* Image */}
        <div className="relative h-52 overflow-hidden bg-gradient-to-br from-[#E9F0E9] to-[#d4e5d4]">
          <img
            src={space.image || "/cosmic-nebula.png"}
            alt={space.name}
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-black/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />

          {/* Category Badge */}
          <div className="absolute top-3 left-3">
            <span className="bg-white/95 backdrop-blur-sm text-black text-xs font-semibold px-3 py-1.5 rounded-full">
              {space.category}
            </span>
          </div>

          {/* Hover Arrow */}
          <div className="absolute bottom-3 right-3 w-10 h-10 bg-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transform translate-y-2 group-hover:translate-y-0 transition-all duration-500">
            <ArrowRight className="text-black" size={18} />
          </div>
        </div>

        {/* Content */}
        <div className="p-5">
          <h3 className="text-xl font-bold text-black mb-2 group-hover:text-black/80 transition-colors line-clamp-1">
            {space.name}
          </h3>

          <div className="flex items-center gap-1.5 text-black/60 mb-3">
            <MapPin size={14} />
            <span className="text-sm line-clamp-1">{space.location}</span>
          </div>

          <p className="text-black/70 text-sm mb-4 line-clamp-2 leading-relaxed">{space.description}</p>

          {/* Stats */}
          <div className="flex items-center justify-between pt-3 border-t border-black/5">
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 bg-[#E9F0E9] rounded-lg flex items-center justify-center">
                <Users size={16} className="text-black" />
              </div>
              <div>
                <p className="text-xs text-black/50 font-medium">Capacity</p>
                <p className="text-sm font-bold text-black">{space.capacity}</p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <div className="w-9 h-9 bg-[#E9F0E9] rounded-lg flex items-center justify-center">
                <DollarSign size={16} className="text-black" />
              </div>
              <div>
                <p className="text-xs text-black/50 font-medium">Per Hour</p>
                <p className="text-sm font-bold text-black">RS.{space.pph}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Link>
  )
}

export default function SpacesPage() {
  const [spaces, setSpaces] = useState<SpaceWithImage[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCategory, setSelectedCategory] = useState<string>("All")

  const headerRef = useRef<HTMLDivElement>(null)
  const titleRef = useRef<HTMLHeadingElement>(null)
  const descRef = useRef<HTMLParagraphElement>(null)
  const filtersRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const fetchSpaces = async () => {
      try {
        const { data: spacesData, error: spacesError } = await supabase.from("spaces").select("*")

        if (spacesError) throw spacesError

        const safeSpaces = Array.isArray(spacesData) ? spacesData : []

        const spacesWithImages = await Promise.all(
          safeSpaces.map(async (space) => {
            const { data: imageData } = await supabase
              .from("spaces-images")
              .select("link")
              .eq("spaceid", space.id)
              .limit(1)
              .single()

            return {
              ...space,
              image: imageData?.link || "/cosmic-nebula.png",
            }
          }),
        )

        setSpaces(spacesWithImages)
      } catch (err) {
        console.error("Error fetching spaces:", err)
        setError(err instanceof Error ? err.message : "Failed to load spaces")
      } finally {
        setLoading(false)
      }
    }

    fetchSpaces()
  }, [])

  const categories = ["All", ...Array.from(new Set(spaces.map((s) => s.category)))]

  const filteredSpaces = spaces.filter((space) => {
    const matchesSearch =
      space.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      space.location.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesCategory = selectedCategory === "All" || space.category === selectedCategory
    return matchesSearch && matchesCategory
  })

  useEffect(() => {
    const ctx = gsap.context(() => {
      const tl = gsap.timeline()

      tl.from(titleRef.current, {
        opacity: 0,
        y: 40,
        duration: 0.4,
        ease: "power3.out",
      })
        .from(
          descRef.current,
          {
            opacity: 0,
            y: 30,
            duration: 0.2,
            ease: "power3.out",
          },
        )
        .from(
          filtersRef.current,
          {
            opacity: 0,
            y: 20,
            duration: 0.2,
            ease: "power3.out",
          },
        )
    })

    return () => {
      ctx.revert()
    }
  }, [])

  return (
    <main className="min-h-screen bg-white">
      {/* Compact Hero Header */}
      <div ref={headerRef} className="relative py-16 md:py-20 bg-gradient-to-br from-[#E9F0E9] via-white to-[#E9F0E9]">
        <div className="absolute top-0 right-0 w-72 h-72 bg-[#E9F0E9] rounded-full blur-3xl opacity-20" />

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 ref={titleRef} className="text-4xl md:text-5xl font-bold text-black mb-3 leading-tight">
            Discover Your
            <span className="block mt-1">Perfect Space</span>
          </h1>
          <p ref={descRef} className="text-lg text-black/70 max-w-2xl">
            Browse our curated collection of premium venues for events, meetings, and celebrations.
          </p>
        </div>
      </div>

      {/* Compact Search and Filters */}
      <div className="sticky top-0 z-40 bg-white/90 backdrop-blur-lg border-b border-black/5">
        <div ref={filtersRef} className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex flex-col md:flex-row gap-3 items-center justify-between">
            {/* Search Bar */}
            <div className="relative flex-1 max-w-md w-full">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-black/40" size={18} />
              <input
                type="text"
                placeholder="Search spaces..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 bg-[#E9F0E9]/30 border border-black/10 rounded-xl focus:outline-none focus:ring-2 focus:ring-black/20 text-sm"
              />
            </div>

            {/* Category Filters */}
            <div className="flex items-center gap-2">
              <Filter size={18} className="text-black/60" />
              {categories.map((category) => (
                <button
                  key={category}
                  onClick={() => setSelectedCategory(category)}
                  className={`px-4 py-2 rounded-full font-medium text-sm transition-all duration-300 ${
                    selectedCategory === category
                      ? "bg-black text-white"
                      : "bg-[#E9F0E9]/50 text-black hover:bg-[#E9F0E9] border border-black/10"
                  }`}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Spaces Grid - Reduced padding */}
      <section className="py-8 md:py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {loading && <p className="text-center text-black/70 py-12">Loading spaces...</p>}
          {error && <p className="text-center text-red-600 py-12">Error: {error}</p>}
          {!loading && filteredSpaces.length === 0 && (
            <div className="text-center py-12">
              <p className="text-xl text-black/60">No spaces found matching your criteria.</p>
            </div>
          )}

          {!loading && filteredSpaces.length > 0 && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredSpaces.map((space, index) => (
                <SpaceCard key={space.id} space={space} index={index} />
              ))}
            </div>
          )}
        </div>
      </section>
    </main>
  )
}
