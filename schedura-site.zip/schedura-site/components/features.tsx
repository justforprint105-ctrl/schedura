"use client"

import { useEffect, useRef } from "react"
import { Calendar, Users, QrCode, Smile, BarChart, ArrowRight } from "lucide-react"
import { gsap } from "gsap"
import { ScrollTrigger } from "gsap/ScrollTrigger"

gsap.registerPlugin(ScrollTrigger)

const features = [
  {
    icon: Calendar,
    title: "Intelligent Booking",
    description: "Seamless scheduling for shared spaces through an intuitive app.",
  },
  {
    icon: QrCode,
    title: "Access Control",
    description: "Automated entry using sensors and QR codes to eliminate ghost bookings.",
  },
  {
    icon: Users,
    title: "Occupancy Tracking",
    description: "Real-time data on space usage and availability for better resource allocation.",
  },
  {
    icon: BarChart,
    title: "Data-Driven Optimization",
    description: "Actionable analytics for admins to make informed decisions.",
  },
  {
    icon: Smile,
    title: "Enhanced User Experience",
    description: "Intuitive design for effortless space management and booking.",
  },
]

const FeatureCard = ({ feature, index }: { feature: typeof features[0], index: number }) => {
  const Icon = feature.icon
  const cardRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    gsap.from(cardRef.current, {
      opacity: 0,
      y: 60,
      duration: 0.8,
      ease: "power3.out",
      scrollTrigger: {
        trigger: cardRef.current,
        start: "top 85%",
        end: "top 65%",
        toggleActions: "play none none none"
      }
    })

    // Hover animation
    const card = cardRef.current
    if (card) {
      card.addEventListener('mouseenter', () => {
        gsap.to(card, {
          scale: 1.05,
          duration: 0.3,
          ease: "power2.out"
        })
      })
      card.addEventListener('mouseleave', () => {
        gsap.to(card, {
          scale: 1,
          duration: 0.3,
          ease: "power2.out"
        })
      })
    }
  }, [])

  return (
    <div 
      ref={cardRef}
      className="p-8 rounded-2xl bg-white border-2 border-black/10 flex flex-col h-full shadow-lg"
    >
      <div className="w-12 h-12 bg-[#E9F0E9] rounded-lg flex items-center justify-center mb-4 border-2 border-black/10">
        <Icon className="text-black" size={24} />
      </div>
      <h3 className="text-xl font-semibold text-black mb-2">{feature.title}</h3>
      <p className="text-black/70 flex-grow">{feature.description}</p>
      <a href="#" className="flex items-center gap-2 mt-4 font-semibold text-black group">
        Learn More 
        <ArrowRight 
          size={16} 
          className="group-hover:translate-x-1 transition-transform" 
        />
      </a>
    </div>
  )
}

export default function Features() {
  const sectionRef = useRef<HTMLElement>(null)
  const headingRef = useRef<HTMLDivElement>(null)
  const buttonRef = useRef<HTMLButtonElement>(null)

  useEffect(() => {
    gsap.from(headingRef.current, {
      opacity: 0,
      y: 40,
      duration: 1,
      ease: "power3.out",
      scrollTrigger: {
        trigger: headingRef.current,
        start: "top 80%",
        toggleActions: "play none none none"
      }
    })

    gsap.from(buttonRef.current, {
      opacity: 0,
      y: 30,
      duration: 0.8,
      ease: "power3.out",
      scrollTrigger: {
        trigger: buttonRef.current,
        start: "top 90%",
        toggleActions: "play none none none"
      }
    })
  }, [])

  return (
    <section 
      ref={sectionRef} 
      id="features" 
      className="py-20 md:py-32 bg-[#E9F0E9]"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div ref={headingRef} className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-bold text-black mb-4">
            Everything You Need. Nothing You Don't.
          </h2>
          <p className="text-lg text-black/70 max-w-2xl mx-auto">
            Comprehensive space management designed with simplicity and security in mind.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <div className="flex flex-col gap-8">
            <FeatureCard feature={features[0]} index={0} />
            <FeatureCard feature={features[1]} index={1} />
          </div>

          <div
              className="transform origin-bottom cursor-pointer flex items-center justify-center"
            >
              <div
                className="w-48 sm:w-56 md:w-64 h-96 sm:h-[420px] md:h-[500px] bg-[#E9F0E9] rounded-3xl shadow-2xl border-4 border-black overflow-hidden flex items-center justify-center"
              >
                <img
                  src="/img5.jpg"
                  alt="Left phone mockup - Booking interface"
                  className="w-full h-full object-fill"
                />
              </div>
            </div>

          <div className="flex flex-col gap-8">
            <FeatureCard feature={features[2]} index={2} />
            <FeatureCard feature={features[3]} index={3} />
          </div>
        </div>

        <div className="mt-8 flex justify-center">
          <div className="w-full lg:w-1/3">
            <FeatureCard feature={features[4]} index={4} />
          </div>
        </div>

        <div className="text-center mt-16">
          <button 
            ref={buttonRef}
            className="bg-black text-white px-8 py-3 rounded-full font-semibold hover:bg-gray-800 transition-all duration-300"
          >
            Explore Full Features
          </button>
        </div>
      </div>
    </section>
  )
}