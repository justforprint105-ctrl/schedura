"use client"

import { useEffect, useRef } from "react"
import { gsap } from "gsap"
import { ScrollTrigger } from "gsap/ScrollTrigger"

gsap.registerPlugin(ScrollTrigger)

export default function Comparison() {
  const sectionRef = useRef<HTMLElement>(null)
  const headingRef = useRef<HTMLDivElement>(null)
  const tableRef = useRef<HTMLDivElement>(null)
  const rowsRef = useRef<(HTMLTableRowElement | null)[]>([])

  const comparisonData = [
    {
      feature: "Occupancy Data",
      traditional: "None / Manual Count",
      basic: "None",
      schedura: "Real-time sensor data",
    },
    {
      feature: "Ghost Bookings",
      traditional: "Very High",
      basic: "High",
      schedura: "Eliminated via QR check-in",
    },
    {
      feature: "Access Control",
      traditional: "Manual (Keys, Staff)",
      basic: "Not Integrated",
      schedura: "Automated & QR-based",
    },
    {
      feature: "Data Analytics",
      traditional: "None",
      basic: "Limited/None",
      schedura: "Actionable insights for admins",
    },
  ]

  useEffect(() => {
    gsap.from(headingRef.current, {
      opacity: 0,
      y: 40,
      duration: 1,
      ease: "power3.out",
      scrollTrigger: {
        trigger: headingRef.current,
        start: "top 80%",
        toggleActions: "play none none none"
      }
    })

    gsap.from(tableRef.current, {
      opacity: 0,
      y: 60,
      duration: 1,
      ease: "power3.out",
      scrollTrigger: {
        trigger: tableRef.current,
        start: "top 80%",
        toggleActions: "play none none none"
      }
    })

    rowsRef.current.forEach((row, index) => {
      if (row) {
        gsap.from(row, {
          opacity: 0,
          x: -30,
          duration: 0.6,
          delay: index * 0.1,
          ease: "power2.out",
          scrollTrigger: {
            trigger: row,
            start: "top 90%",
            toggleActions: "play none none none"
          }
        })
      }
    })
  }, [])

  return (
    <section 
      ref={sectionRef} 
      id="comparison" 
      className="py-20 md:py-32 bg-white"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div ref={headingRef} className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-bold text-black mb-4">
            How We Are Different
          </h2>
          <p className="text-lg text-black/70 max-w-2xl mx-auto">
            Schedura provides a fully integrated solution that modernizes space management.
          </p>
        </div>

        <div ref={tableRef} className="overflow-x-auto">
          <table className="w-full text-left border-collapse bg-white rounded-lg shadow-xl border-2 border-black/10">
            <thead>
              <tr>
                <th className="py-4 px-6 bg-[#E9F0E9] text-black font-semibold rounded-tl-lg border-b-2 border-black/10">
                  Feature
                </th>
                <th className="py-4 px-6 bg-[#E9F0E9] text-black font-semibold border-b-2 border-black/10">
                  Traditional Methods
                </th>
                <th className="py-4 px-6 bg-[#E9F0E9] text-black font-semibold border-b-2 border-black/10">
                  Basic Booking Apps
                </th>
                <th className="py-4 px-6 bg-black text-white font-semibold rounded-tr-lg border-b-2 border-black">
                  Schedura Platform
                </th>
              </tr>
            </thead>
            <tbody>
              {comparisonData.map((row, index) => (
                <tr 
                  key={index} 
                  ref={el => { rowsRef.current[index] = el; }}
                  className="border-b border-black/10 last:border-b-0 hover:bg-[#E9F0E9] transition-colors duration-300"
                >
                  <td className="py-4 px-6 font-medium text-black">{row.feature}</td>
                  <td className="py-4 px-6 text-black/70">{row.traditional}</td>
                  <td className="py-4 px-6 text-black/70">{row.basic}</td>
                  <td className="py-4 px-6 text-black font-semibold">{row.schedura}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </section>
  )
}