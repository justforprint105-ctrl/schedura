export interface Space {
  id?: string
  name: string
  location?: string
  latitude?: number | null
  longitude?: number | null
  description?: string | null
  pph?: number | null
  capacity?: number | null
  ownerid?: string | null
  organizationid?: string | null
  category?: string | null
  phone?: string | null
  amenities?: string[]
}
