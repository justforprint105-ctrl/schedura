"use client"
import { ArrowRight } from "lucide-react"
import { motion } from "framer-motion"
import type { Variants } from "framer-motion"
import Link from "next/link"

export default function Hero() {
  const containerVariants: Variants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2,
      },
    },
  }

  const itemVariants: Variants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.8,
        ease: "easeOut",
      },
    },
  }

  const phoneVariants: Variants = {
    hidden: { opacity: 0, y: 60 },
    visible: (i: number) => ({
      opacity: 1,
      y: 0,
      transition: {
        duration: 1,
        delay: 0.5 + i * 0.15,
        ease: [0.23, 1, 0.32, 1],
      },
    }),
  }

  const floatingVariants: Variants = {
    animate: (i: number) => ({
      y: [0, -12 - i * 4, 0],
      transition: {
        duration: 4 + i * 0.5,
        repeat: Number.POSITIVE_INFINITY,
        ease: "easeInOut",
      },
    }),
  }

  return (
    <section className="relative pt-20 pb-20 px-4 sm:px-6 md:pt-32 md:pb-24 bg-white overflow-hidden">
      <div className="max-w-7xl mx-auto">
        <motion.div className="text-center" variants={containerVariants} initial="hidden" animate="visible">

          {/* Heading */}
          <motion.h1
            variants={itemVariants}
            className="text-4xl sm:text-5xl md:text-7xl font-bold text-black mb-4 md:mb-6 leading-tight"
          >
            Schedura: Smart Spaces
            <span className="block mt-2">App-Based Platform</span>
          </motion.h1>

          {/* Paragraph */}
          <motion.p
            variants={itemVariants}
            className="text-lg sm:text-xl text-black/70 max-w-2xl md:max-w-3xl mx-auto mb-8 md:mb-12 leading-relaxed"
          >
            Intelligent booking and real-time occupancy tracking to streamline the management of shared resources in
            academic, corporate, and co-living environments.
          </motion.p>

          {/* Buttons */}
          <motion.div
            variants={itemVariants}
            className="flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center mb-12 md:mb-16"
          >
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="group bg-black text-white px-6 sm:px-8 py-3 sm:py-4 rounded-full font-semibold hover:bg-gray-800 transition-all duration-300 flex items-center justify-center gap-2"
            >
              <Link
                href="/spaces"
              >View Spaces</Link>
              <ArrowRight className="group-hover:translate-x-1 transition-transform" size={20} />
            </motion.button>
          </motion.div>

          <div className="relative mt-12 md:mt-20 flex justify-center items-end gap-2 sm:gap-3 md:gap-6 flex-wrap md:flex-nowrap">
            {/* Left Phone */}
            <motion.div
              custom={0}
              variants={phoneVariants}
              initial="hidden"
              animate="visible"
              whileHover={{ scale: 1.08, rotate: 0 }}
              className="transform -rotate-6 origin-bottom cursor-pointer"
            >
              <motion.div
                custom={0}
                animate="animate"
                variants={floatingVariants}
                className="w-48 sm:w-56 md:w-64 h-96 sm:h-[420px] md:h-[500px] bg-[#E9F0E9] rounded-3xl shadow-2xl border-4 border-black overflow-hidden flex items-center justify-center"
              >
                <img
                  src="/img4.jpg"
                  alt="Left phone mockup - Booking interface"
                  className="w-full h-full object-fill"
                />
              </motion.div>
            </motion.div>

            {/* Center Phone */}
            <motion.div
              custom={1}
              variants={phoneVariants}
              initial="hidden"
              animate="visible"
              whileHover={{ scale: 1.08 }}
              className="origin-bottom cursor-pointer z-10"
            >
              <motion.div
                custom={1}
                animate="animate"
                variants={floatingVariants}
                className="w-56 sm:w-64 md:w-72 h-[440px] sm:h-[480px] md:h-[580px] bg-white rounded-3xl shadow-2xl border-4 border-black overflow-hidden flex items-center justify-center"
              >
                <img
                  src="/img2.jpg"
                  alt="Center phone mockup - Main dashboard"
                  className="w-full h-full object-fill"
                />
              </motion.div>
            </motion.div>

            {/* Right Phone */}
            <motion.div
              custom={2}
              variants={phoneVariants}
              initial="hidden"
              animate="visible"
              whileHover={{ scale: 1.08, rotate: 0 }}
              className="transform rotate-6 origin-bottom cursor-pointer"
            >
              <motion.div
                custom={2}
                animate="animate"
                variants={floatingVariants}
                className="w-48 sm:w-56 md:w-64 h-96 sm:h-[420px] md:h-[500px] bg-[#E9F0E9] rounded-3xl shadow-2xl border-4 border-black overflow-hidden flex items-center justify-center"
              >
                <img
                  src="/img3.jpg"
                  alt="Right phone mockup - Map view tracking"
                  className="w-full h-full object-fill"
                />
              </motion.div>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
