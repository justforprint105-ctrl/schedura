'use client'

import React, { useEffect, useRef } from 'react'
import gsap from 'gsap'
import {useGSAP} from '@gsap/react'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

gsap.registerPlugin(ScrollTrigger)

const Navbar = () => {

    let listRef = useRef<HTMLUListElement>(null)
    let navRef = useRef<HTMLDivElement>(null)
    

    useGSAP (() => {

        let lastScroll = window.scrollY

        ScrollTrigger.create({
            start: 'top top',
            end: 'max',
            onUpdate: (self) => {
                const currentScroll = self.scroll()
                const direction = self.direction

                if(direction === 1) {
                    gsap.to(navRef.current, {
                        y: -100,
                        duration: 1,
                        ease: 'power2.out'
                    })
                } else {
                    gsap.to(navRef.current, {
                      y: 0,
                      duration: 1,
                      ease: 'power2.out'
                    })
                }
                lastScroll = currentScroll
            }
        })

        // gsap.fromTo(navRef.current, {
        //     y: 0,
        // }, {
        //     y: -100,
        //     scrollTrigger: {
        //         trigger: navRef.current,
        //         markers: true,
        //         start: '+=20 top',
        //         scrub: true,
        //         end: 'bottom ',
        //     }

        // })
    })

  return (
    <div ref={navRef} className='fixed top-0 left-0 right-0 h-24 w-full bg-white z-[999]'>
        <div className='flex h-full  justify-center items-center mx-32 '>
            <div className='logo w-1/2 '>
                <h1 className='text-4xl font-bold'>SCHEDURA.</h1>
            </div>
            <div className=' w-1/2 '>
                <ul ref={listRef} className='text-black lists flex justify-end text-xl space-x-5'>
                    {/* <li>Home</li>
                    <li>About</li>
                    <li>Services</li>
                    <li>Support</li> */}
                </ul>
            </div>
        </div>
    </div>
  )
}

export default Navbar