"use client"

import { useEffect, useRef } from "react"
import { Star } from "lucide-react"
import { gsap } from "gsap"
import { ScrollTrigger } from "gsap/ScrollTrigger"

gsap.registerPlugin(ScrollTrigger)

const testimonials = [
  {
    name: "Dr. Emily Carter",
    role: "University Administrator",
    content:
      "Schedura has transformed how we manage campus resources. The real-time analytics helped us optimize lab usage by 40%.",
    rating: 5,
  },
  {
    name: "Alex Johnson",
    role: "Corporate Facilities Manager",
    content: "Ghost bookings were a constant headache. Schedura's QR check-in system completely eliminated the problem for our meeting rooms.",
    rating: 5,
  },
  {
    name: "Priya Sharma",
    role: "Student Event Coordinator",
    content: "Booking a hall for our club used to take days. Now, I can see availability and get instant approval through the app. It's a game-changer.",
    rating: 5,
  },
]

export default function Testimonials() {
  const sectionRef = useRef<HTMLElement>(null)
  const headingRef = useRef<HTMLDivElement>(null)
  const cardsRef = useRef<(HTMLDivElement | null)[]>([])

  useEffect(() => {
    gsap.from(headingRef.current, {
      opacity: 0,
      y: 40,
      duration: 1,
      ease: "power3.out",
      scrollTrigger: {
        trigger: headingRef.current,
        start: "top 80%",
        toggleActions: "play none none none"
      }
    })

    cardsRef.current.forEach((card, index) => {
      if (card) {
        gsap.from(card, {
          opacity: 0,
          y: 60,
          duration: 0.8,
          delay: index * 0.2,
          ease: "power3.out",
          scrollTrigger: {
            trigger: card,
            start: "top 85%",
            toggleActions: "play none none none"
          }
        })

        // Hover animation
        card.addEventListener('mouseenter', () => {
          gsap.to(card, {
            y: -10,
            duration: 0.3,
            ease: "power2.out"
          })
        })
        card.addEventListener('mouseleave', () => {
          gsap.to(card, {
            y: 0,
            duration: 0.3,
            ease: "power2.out"
          })
        })
      }
    })
  }, [])

  return (
    <section 
      ref={sectionRef} 
      id="testimonials" 
      className="py-20 md:py-32 bg-[#E9F0E9]"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div ref={headingRef} className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-bold text-black mb-4">
            Real People. Real Results.
          </h2>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div
              key={index}
              ref={el => { cardsRef.current[index] = el; }}
              className="p-8 rounded-2xl bg-white border-2 border-black/10 shadow-lg"
            >
              <div className="flex gap-1 mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} size={16} className="fill-black text-black" />
                ))}
              </div>
              <p className="text-black mb-6 italic leading-relaxed">"{testimonial.content}"</p>
              <div>
                <p className="font-semibold text-black">{testimonial.name}</p>
                <p className="text-sm text-black/70">{testimonial.role}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}