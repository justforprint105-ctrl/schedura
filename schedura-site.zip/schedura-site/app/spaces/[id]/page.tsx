"use client"

import { useEffect, useRef, useState } from "react"
import { useParams } from "next/navigation"
import Link from "next/link"
import { gsap } from "gsap"
import { MapPin, Users, Phone, ArrowLeft, Share2 } from "lucide-react"
import { supabase } from "@/lib/supabase"

interface Space {
  id: string
  name: string
  location: string
  capacity?: number | null
  pph?: string | number | null
  category?: string | null
  description?: string | null
  phone?: string | number | null
  ownerid?: string | null
  organizationid?: number | string | null
  updated_at?: string | null
  latitude?: number | null
  longitude?: number | null
}

const ImageGallery = ({ images }: { images: string[] }) => {
  const [mainImage, setMainImage] = useState(images[0] || "/cosmic-nebula.png")
  const [imageIndex, setImageIndex] = useState(0)
  const galleryRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const ctx = gsap.context(() => {
      if (galleryRef.current) {
        gsap.from(galleryRef.current, {
          opacity: 0,
          y: 30,
          duration: 0.8,
          ease: "power3.out",
        })
      }
    })

    return () => {
      ctx.revert()
    }
  }, [])

  return (
    <div ref={galleryRef} className="space-y-3">
      {/* Main Image */}
  <div className="relative w-full h-[400px] rounded-2xl overflow-hidden bg-gradient-to-br from-[#E9F0E9] to-[#d4e5d4] shadow-lg group">
        <img
          src={mainImage || "/placeholder.svg"}
          alt="Space view"
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
        />

        {/* Image Counter */}
        {images.length > 1 && (
          <div className="absolute bottom-4 right-4 bg-[#E9F0E9]/80 backdrop-blur-sm text-black px-3 py-1.5 rounded-full text-sm font-medium">
            {imageIndex + 1} / {images.length}
          </div>
        )}
      </div>

      {/* Thumbnail Grid */}
      {images.length > 1 && (
        <div className="grid grid-cols-4 gap-3">
          {images.map((image, idx) => (
            <div
              key={idx}
              className={`relative h-20 rounded-xl overflow-hidden cursor-pointer transition-all duration-300 ${
                mainImage === image
                  ? "ring-3 ring-[#E9F0E9] scale-105"
                  : "ring-1 ring-[#E9F0E9]/10 hover:ring-[#E9F0E9]/30 hover:scale-105"
              }`}
              onClick={() => {
                setMainImage(image)
                setImageIndex(idx)
              }}
            >
              <img src={image || "/placeholder.svg"} alt={`View ${idx + 1}`} className="w-full h-full object-cover" />
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

export default function SpaceDetailPage() {
  const params = useParams()
  const id = params.id as string
  const [space, setSpace] = useState<Space | null>(null)
  const [images, setImages] = useState<string[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const headerRef = useRef<HTMLDivElement>(null)
  const contentRef = useRef<HTMLDivElement>(null)
  const sidebarRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const fetchSpace = async () => {
      try {
        const { data: spaceData, error: spaceError } = await supabase.from("spaces").select("*").eq("id", id).single()

        if (spaceError) throw spaceError
        if (!spaceData) throw new Error("Space not found")
  // debug: log raw payload so we can confirm field names returned by Supabase
  // open browser console to inspect this object when the page loads
  // eslint-disable-next-line no-console
  console.debug("[debug] spaceData:", spaceData)
  setSpace(spaceData)

  const { data: imageData } = await supabase.from("spaces-images").select("link").eq("spaceid", id)

  // eslint-disable-next-line no-console
  console.debug("[debug] imageData:", imageData)
  setImages((imageData || []).map((img) => img.link))
      } catch (err) {
        console.error("Error fetching space:", err)
        setError(err instanceof Error ? err.message : "Failed to load space")
      } finally {
        setLoading(false)
      }
    }

    if (id) {
      fetchSpace()
    }
  }, [id])

  useEffect(() => {
    if (!space) return

    const ctx = gsap.context(() => {
      const tl = gsap.timeline()

      tl.from(headerRef.current, {
        opacity: 0,
        y: -20,
        duration: 0.6,
        ease: "power3.out",
      })
        .from(
          contentRef.current,
          {
            opacity: 0,
            y: 40,
            duration: 0.8,
            ease: "power3.out",
          },
          "-=0.3",
        )
        .from(
          sidebarRef.current,
          {
            opacity: 0,
            x: 40,
            duration: 0.8,
            ease: "power3.out",
          },
          "-=0.6",
        )
    })

    return () => {
      ctx.revert()
    }
  }, [space])

  if (loading) {
    return (
      <main className="min-h-screen bg-white flex items-center justify-center">
        <p className="text-black/70">Loading space details...</p>
      </main>
    )
  }

  if (error || !space) {
    return (
      <main className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-4xl font-bold text-black mb-4">Space Not Found</h1>
          <p className="text-black/70 mb-6">{error || "This space could not be found."}</p>
          <Link href="/spaces" className="text-blue-600 hover:underline">
            Back to Spaces
          </Link>
        </div>
      </main>
    )
  }

  return (
    <main className="min-h-screen bg-white">
      {/* Compact Navigation Bar */}
  <div ref={headerRef} className="sticky top-0 z-50 bg-white/90 backdrop-blur-lg border-b border-[#E9F0E9]/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
          <div className="flex items-center justify-between">
            <Link
              href="/spaces"
              className="inline-flex items-center gap-2 text-black hover:text-black/70 transition-colors group"
            >
              <div className="w-9 h-9 bg-[#E9F0E9] rounded-full flex items-center justify-center group-hover:bg-[#E9F0E9] group-hover:text-black transition-all">
                <ArrowLeft size={18} />
              </div>
              <span className="font-semibold text-sm">Back</span>
            </Link>

            <button className="inline-flex items-center gap-2 px-5 py-2 bg-[#E9F0E9] rounded-full hover:bg-[#E9F0E9]/90 hover:text-black transition-all duration-300 font-medium text-sm">
              <Share2 size={16} />
              Share
            </button>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="py-8 md:py-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Main Content */}
            <div ref={contentRef} className="lg:col-span-2 space-y-6">
              {/* Header Info */}
              <div>
                <span className="inline-block bg-[#E9F0E9] text-black text-sm font-semibold px-4 py-1.5 rounded-full mb-3">
                  {space.category}
                </span>

                <h1 className="text-4xl md:text-5xl font-bold text-black mb-3 leading-tight">{space.name}</h1>

                <div className="flex items-center gap-2 text-black/70">
                  <MapPin size={18} />
                  <span>{space.location}</span>
                </div>
              </div>

              {/* Gallery */}
              <ImageGallery images={images.length > 0 ? images : ["/cosmic-nebula.png"]} />

              {/* Description */}
              <div className="bg-white rounded-2xl p-6 border border-[#E9F0E9]/5">
                <h2 className="text-2xl font-bold text-black mb-4">About This Space</h2>
                <p className="text-black/70 leading-relaxed">{space.description}</p>
              </div>
            </div>

            {/* Compact Sidebar */}
            <div ref={sidebarRef} className="lg:col-span-1">
              <div className="sticky top-20 space-y-4">
                {/* Pricing Card */}
                <div className="bg-gradient-to-br from-[#E9F0E9] to-[#d4e5d4] rounded-2xl p-6 text-black">
                  <div className="text-center mb-6">
                    <p className="text-black/70 text-sm mb-1">Starting from</p>
                    <div className="text-4xl font-bold">
                      Rs.{space.pph}
                      <span className="text-xl text-black/70">/day</span>
                    </div>
                  </div>

                  {/* Quick Stats */}
                  <div className="space-y-3 mb-6 pb-6 border-b border-white/10">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-[#E9F0E9]/10 rounded-lg flex items-center justify-center">
                        <Users size={18} />
                      </div>
                      <div>
                        <p className="text-black/70 text-xs">Capacity</p>
                        <p className="font-bold text-black">{space.capacity} People</p>
                      </div>
                    </div>

                    {space.phone && (
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-[#E9F0E9]/10 rounded-lg flex items-center justify-center">
                          <Phone size={18} />
                        </div>
                        <div>
                          <p className="text-black/70 text-xs">Contact</p>
                          <p className="font-bold text-sm text-black">{space.phone}</p>
                        </div>
                      </div>
                    )}
                  </div>
                </div>

              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  )
}
