"use client"

import { useEffect, useRef } from "react"
import { Facebook, Twitter, Linkedin, Instagram } from "lucide-react"
import { gsap } from "gsap"
import { ScrollTrigger } from "gsap/ScrollTrigger"

gsap.registerPlugin(ScrollTrigger)

export default function Footer() {
  const footerRef = useRef<HTMLElement>(null)
  const columnsRef = useRef<(HTMLDivElement | null)[]>([])
  const bottomRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    columnsRef.current.forEach((column, index) => {
      if (column) {
        gsap.from(column, {
          opacity: 0,
          y: 40,
          duration: 0.8,
          delay: index * 0.1,
          ease: "power3.out",
          scrollTrigger: {
            trigger: column,
            start: "top 90%",
            toggleActions: "play none none none"
          }
        })
      }
    })

    gsap.from(bottomRef.current, {
      opacity: 0,
      y: 20,
      duration: 0.8,
      ease: "power3.out",
      scrollTrigger: {
        trigger: bottomRef.current,
        start: "top 95%",
        toggleActions: "play none none none"
      }
    })
  }, [])

  return (
    <footer ref={footerRef} className="bg-[#E9F0E9]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid md:grid-cols-4 gap-8 mb-12">
          <div ref={el => { columnsRef.current[0] = el }}>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 bg-black rounded-lg flex items-center justify-center">
                <span className="text-white font-bold">S</span>
              </div>
              <span className="font-bold text-lg text-black">Schedura</span>
            </div>
            <p className="text-black/70">Intelligent space management.</p>
          </div>

          <div ref={el => { columnsRef.current[1] = el }}>
            <h4 className="font-semibold mb-4 text-black">Project Team</h4>
            <ul className="space-y-2 text-black/70">
              <li>Shridhar Kamat</li>
              <li>Shubh Solanki</li>
              <li>Sanish Pagui</li>
            </ul>
          </div>

          <div ref={el => { columnsRef.current[2] = el }}>
            <h4 className="font-semibold mb-4 text-black">Links</h4>
            <ul className="space-y-2 text-black/70">
              <li>
                <a href="#" className="hover:text-black transition">
                  Features
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-black transition">
                  Pricing
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-black transition">
                  Documentation
                </a>
              </li>
            </ul>
          </div>

          <div ref={el => { columnsRef.current[3] = el }}>
            <h4 className="font-semibold mb-4 text-black">Contact</h4>
            <p className="text-black/70 mb-4">
              Email: contact@schedura.app
            </p>
          </div>
        </div>

        <div 
          ref={bottomRef}
          className="border-t border-black/20 pt-8 flex flex-col md:flex-row justify-between items-center"
        >
          <p className="text-black/70 mb-4 md:mb-0">© 2025 Schedura. All rights reserved.</p>
          <div className="flex gap-4">
            <a 
              href="#" 
              className="text-black/70 hover:text-black transition"
            >
              <Facebook size={20} />
            </a>
            <a 
              href="#" 
              className="text-black/70 hover:text-black transition"
            >
              <Twitter size={20} />
            </a>
            <a 
              href="#" 
              className="text-black/70 hover:text-black transition"
            >
              <Linkedin size={20} />
            </a>
            <a 
              href="#" 
              className="text-black/70 hover:text-black transition"
            >
              <Instagram size={20} />
            </a>
          </div>
        </div>
      </div>
    </footer>
  )
}